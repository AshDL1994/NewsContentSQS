import boto3
client = boto3.client('sqs')

def create_queue_return_url(name):
        
        aws_response = client.create_queue(
            QueueName=name
        )
        
        queue_url = client.get_queue_url(
            QueueName=name,     
        )

        return queue_url["QueueUrl"] #double check this and its necessity 



def list_all_queues():
    try:
        queue_list_object = client.list_queues()["QueueUrls"]
        list_names_only = [title[title.rfind('/')+1:] for title in queue_list_object]
        return list_names_only
    except:
        return "are you sure you actually have queues to search for?"


def send_message_to_queue(queue_url, message_body):
        try:
            aws_message = client.send_message(
                QueueUrl=queue_url,
                MessageBody=message_body
                )
            queue_name = queue_url[queue_url.rfind('/')+1:]
            return f"Message sent to the que named '{queue_name}'!"
        except:
              return f"Can't find that queue!"
        

def list_all_queues():
    try:
        queue_list_object = client.list_queues()["QueueUrls"]
        list_names_only = [title[title.rfind('/')+1:] for title in queue_list_object]
        return list_names_only
    except:
        return "are you sure you actually have queues to search for?"
